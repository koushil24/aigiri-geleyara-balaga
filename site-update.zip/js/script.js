// =====================================================
// AIGIRI GELEYARA BALAGA - Main script
// 1 Theme  2 Language  3 Menu  4 Scroll  5 Team
// 6 Loader  7 Slider  8 Countdown
// =====================================================


// ===== 1. Theme (light / dark) =====
const themeBtn = document.getElementById("themeBtn");
const body = document.body;

function applyTheme(dark) {
    body.classList.toggle("dark-mode", dark);
    themeBtn.textContent = dark ? "☀️" : "🌙";
    localStorage.setItem("theme", dark ? "dark" : "light");
}

applyTheme(localStorage.getItem("theme") === "dark");

themeBtn.addEventListener("click", () => {
    applyTheme(!body.classList.contains("dark-mode"));
});


// ===== 2. Language (Kannada / English) =====
// Every element with data-i18n="key" is translated using the text below.
// To change any text on the website, edit it here (both kn and en).
const translations = {
    "kn": {
        "sheet-birthday": "ಹುಟ್ಟುಹಬ್ಬ ಪೋಸ್ಟರ್",
        "sheet-member": "ಸದಸ್ಯ ಐಡಿ",
        "gal-title": "📸 ಕಾರ್ಯಕ್ರಮ ಗ್ಯಾಲರಿ",
        "gal-sub": "ನಮ್ಮ ಆಚರಣೆಗಳ ಫೋಟೋ ಮತ್ತು ರೀಲ್‌ಗಳು",
        "gal-empty": "ಫೋಟೋಗಳನ್ನು ಶೀಘ್ರದಲ್ಲೇ ಸೇರಿಸಲಾಗುವುದು.",
        "reel-title": "ನಮ್ಮ ರೀಲ್‌ಗಳನ್ನು ವೀಕ್ಷಿಸಿ",
        "cd-starts": "ಕಾರ್ಯಕ್ರಮ ಆರಂಭಕ್ಕೆ ಉಳಿದ ಸಮಯ",
        "nav-home": "ಮುಖಪುಟ",
        "nav-about": "ನಮ್ಮ ಬಗ್ಗೆ",
        "nav-events": "ಕಾರ್ಯಕ್ರಮಗಳು",
        "nav-team": "AGB ತಂಡ",
        "nav-gallery": "ಗ್ಯಾಲರಿ",
        "nav-sponsor": "ಬೆಂಬಲ",
        "nav-contact": "ಸಂಪರ್ಕಿಸಿ",
        "hero-title": "ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ",
        "hero-city": "ಮೈಸೂರು",
        "hero-tagline": "ಸೇವೆ • ಸ್ನೇಹ • ಸಂಸ್ಕೃತಿ",
        "btn-events": "ಕಾರ್ಯಕ್ರಮಗಳು",
        "connect": "ನಮ್ಮೊಂದಿಗೆ ಸಂಪರ್ಕದಲ್ಲಿರಿ",
        "insta-follow": "Instagram ನಲ್ಲಿ ಫಾಲೋ ಮಾಡಿ",
        "threads-official": "ಅಧಿಕೃತ ಪುಟ",
        "slide-title": "ಗಣೇಶೋತ್ಸವ 2025",
        "slide-sub": "ಏಕತೆ • ಭಕ್ತಿ • ಸ್ನೇಹದ ನೆನಪುಗಳು",
        "upcoming-title": "✨ ಮುಂಬರುವ ಕಾರ್ಯಕ್ರಮಗಳು ✨",
        "past-title": "🕰️ ಹಿಂದಿನ ಕಾರ್ಯಕ್ರಮಗಳು",
        "t-ashada": "🪔 ಆಷಾಢ ಶುಕ್ರವಾರ ಪೂಜಾ ಮಹೋತ್ಸವ",
        "t-ganesh": "🐘 ಗಣೇಶೋತ್ಸವ",
        "d-ashada27": "📅 30 ಜುಲೈ 2027",
        "d-ganesh27": "📅 04 ಸೆಪ್ಟೆಂಬರ್ 2027",
        "cd-days": "ದಿನ",
        "cd-hours": "ಗಂಟೆ",
        "cd-mins": "ನಿಮಿಷ",
        "cd-secs": "ಸೆಕೆಂಡ್",
        "cd-live": "🙏 ಕಾರ್ಯಕ್ರಮ ಪ್ರಾರಂಭವಾಗಿದೆ",
        "watch": "▶ Instagram ನಲ್ಲಿ ವೀಕ್ಷಿಸಿ",
        "about-title": "ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗದ ಬಗ್ಗೆ",
        "about-sub": "ಸ್ನೇಹ, ಸಂಸ್ಕೃತಿ ಮತ್ತು ಏಕತೆಯ ಮೂಲಕ ಸಮಾಜ ಸೇವೆ",
        "about-p1": "<strong>ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ (AGB), ಮೈಸೂರು</strong> ಸ್ನೇಹ, ಸಂಸ್ಕೃತಿ, ಆಧ್ಯಾತ್ಮಿಕತೆ ಮತ್ತು ಸಮಾಜ ಸೇವೆಯ ಮೂಲಕ ಜನರನ್ನು ಒಟ್ಟುಗೂಡಿಸುವ ಉದ್ದೇಶದಿಂದ <strong>2025</strong>ರಲ್ಲಿ ಸ್ಥಾಪಿತವಾದ ಯುವಕರ ಸಮುದಾಯ ಸಂಘಟನೆಯಾಗಿದೆ.",
        "about-p2": "ಸ್ಥಾಪನೆಯಾದಾಗಿನಿಂದ AGB ಧಾರ್ಮಿಕ ಆಚರಣೆಗಳು, ಸಾಂಸ್ಕೃತಿಕ ಕಾರ್ಯಕ್ರಮಗಳು, ಸಾಮಾಜಿಕ ಚಟುವಟಿಕೆಗಳು ಮತ್ತು ಸಮುದಾಯ ಸೇವಾ ಕಾರ್ಯಗಳನ್ನು ಸಕ್ರಿಯವಾಗಿ ಆಯೋಜಿಸುತ್ತಾ, ಯುವಕರು ಮತ್ತು ಸಮಾಜದಲ್ಲಿ ಏಕತೆ ಹಾಗೂ ಉತ್ತಮ ಮೌಲ್ಯಗಳನ್ನು ಬೆಳೆಸುತ್ತಿದೆ.",
        "about-p3": "ನಮ್ಮ ಪ್ರಮುಖ ಆಚರಣೆಗಳಲ್ಲಿ <strong>ಗಣೇಶೋತ್ಸವ</strong>, <strong>ಆಷಾಢ ಶುಕ್ರವಾರ ಪೂಜಾ ಮಹೋತ್ಸವ</strong> ಮತ್ತು ಸಮಾಜ ಸೇವೆ, ಸಂಪ್ರದಾಯ ಸಂರಕ್ಷಣೆ ಹಾಗೂ ಸ್ವಯಂಸೇವೆಯನ್ನು ಪ್ರೋತ್ಸಾಹಿಸುವ ಮುಂದಿನ ಹಲವು ಉಪಕ್ರಮಗಳು ಸೇರಿವೆ.",
        "about-p4": "ನಿಜವಾದ ಸ್ನೇಹವು ಸೇವೆ, ಗೌರವ, ನಾಯಕತ್ವ ಮತ್ತು ಸಾಮೂಹಿಕ ಜವಾಬ್ದಾರಿಗೆ ಪ್ರೇರಣೆ ನೀಡಿದಾಗ ಅರ್ಥಪೂರ್ಣವಾಗುತ್ತದೆ ಎಂದು ನಾವು ನಂಬುತ್ತೇವೆ. AGB ಯ ಪ್ರತಿಯೊಬ್ಬ ಸದಸ್ಯರೂ ಬಲಿಷ್ಠ, ಒಗ್ಗೂಡಿದ ಮತ್ತು ಕರುಣಾಮಯಿ ಸಮುದಾಯವನ್ನು ಕಟ್ಟುವಲ್ಲಿ ಕೊಡುಗೆ ನೀಡುತ್ತಾರೆ.",
        "motto-title": "<strong>ನಮ್ಮ ಧ್ಯೇಯ:</strong>",
        "motto-1": "🟡 ಸೇವೆ • ಸ್ನೇಹ • ಸಂಸ್ಕೃತಿ",
        "motto-2": "🙏 ಒಟ್ಟಾಗಿ ಬೆಳೆಯೋಣ, ಒಟ್ಟಾಗಿ ಸೇವೆ ಮಾಡೋಣ.",
        "team-title": "👥 AGB ತಂಡ",
        "team-subtitle": "ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗದ ಸದಸ್ಯರು",
        "gallery-title": "📸 ಗ್ಯಾಲರಿ",
        "gallery-subtitle": "ನಮ್ಮ ಕಾರ್ಯಕ್ರಮಗಳ ನೆನಪುಗಳು",
        "g-ashada": "🪔 ಆಷಾಢ ಪೂಜಾ",
        "g-ganesh": "🐘 ಗಣೇಶೋತ್ಸವ",
        "sponsor-title": "🤝 ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗವನ್ನು ಬೆಂಬಲಿಸಿ",
        "sponsor-sub": "ನಮ್ಮ ಸಾಂಸ್ಕೃತಿಕ, ಧಾರ್ಮಿಕ ಮತ್ತು ಸಮುದಾಯ ಸೇವಾ ಚಟುವಟಿಕೆಗಳನ್ನು ಬೆಂಬಲಿಸಲು ಬಯಸುವ ವ್ಯಕ್ತಿಗಳು, ಉದ್ಯಮಗಳು ಮತ್ತು ಹಿತೈಷಿಗಳನ್ನು ನಾವು ಸ್ವಾಗತಿಸುತ್ತೇವೆ. ಸ್ವಯಂಸೇವೆ, ಸಾಮಗ್ರಿ ಅಥವಾ ಕಾರ್ಯಕ್ರಮ ಬೆಂಬಲದ ಮೂಲಕ ನೀಡುವ ಪ್ರತಿಯೊಂದು ಕೊಡುಗೆಯೂ ಸಮಾಜಕ್ಕೆ ಉತ್ತಮ ಸೇವೆ ಸಲ್ಲಿಸಲು ನಮಗೆ ನೆರವಾಗುತ್ತದೆ.",
        "sp1-t": "🎉 ಕಾರ್ಯಕ್ರಮ ಬೆಂಬಲ",
        "sp1-p": "ನಮ್ಮ ಸಾಂಸ್ಕೃತಿಕ ಮತ್ತು ಸಮುದಾಯ ಕಾರ್ಯಕ್ರಮಗಳ ಯಶಸ್ವಿ ಆಯೋಜನೆಗೆ ಬೆಂಬಲ ನೀಡಿ.",
        "sp2-t": "🍛 ಅನ್ನದಾನ ಬೆಂಬಲ",
        "sp2-p": "ನಮ್ಮ ಧಾರ್ಮಿಕ ಮತ್ತು ಸಮುದಾಯ ಕಾರ್ಯಕ್ರಮಗಳಲ್ಲಿ ಪ್ರಸಾದ ಮತ್ತು ಆಹಾರ ವಿತರಣೆಗೆ ಬೆಂಬಲ ನೀಡಿ.",
        "sp3-t": "🎵 ಧ್ವನಿ ಮತ್ತು ವೇದಿಕೆ ಬೆಂಬಲ",
        "sp3-p": "ಧ್ವನಿ ವ್ಯವಸ್ಥೆ, ದೀಪಾಲಂಕಾರ, ವೇದಿಕೆ ಸಿದ್ಧತೆ ಮತ್ತು ಕಾರ್ಯಕ್ರಮದ ವ್ಯವಸ್ಥೆಗಳಿಗೆ ಬೆಂಬಲ ನೀಡಿ.",
        "sp4-t": "🎁 ಸಾಮಗ್ರಿ ಬೆಂಬಲ",
        "sp4-p": "ಹೂವುಗಳು, ಅಲಂಕಾರ, ಪೂಜಾ ಸಾಮಗ್ರಿ, ಕುಡಿಯುವ ನೀರು, ಕುರ್ಚಿಗಳು ಮತ್ತು ಇತರ ಕಾರ್ಯಕ್ರಮ ಸಾಮಗ್ರಿಗಳಿಗೆ ಬೆಂಬಲ ನೀಡಿ.",
        "sp5-t": "🙋 ಸ್ವಯಂಸೇವಕರಾಗಿ",
        "sp5-p": "ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗದ ಸ್ವಯಂಸೇವಕರಾಗಿ ಸೇರಿ, ಸಮುದಾಯಕ್ಕೆ ಶ್ರದ್ಧೆಯಿಂದ ಸೇವೆ ಸಲ್ಲಿಸಲು ನಮಗೆ ಸಹಾಯ ಮಾಡಿ.",
        "sponsor-cta": "ನಮ್ಮ ಚಟುವಟಿಕೆಗಳನ್ನು ಬೆಂಬಲಿಸಲು ಆಸಕ್ತಿ ಇದೆಯೇ?",
        "sponsor-insta": "📷 Instagram ನಲ್ಲಿ ಸಂಪರ್ಕಿಸಿ",
        "sponsor-threads": "🧵 Threads ನಲ್ಲಿ ಸಂಪರ್ಕಿಸಿ",
        "contact-title": "📍 ಸಂಪರ್ಕಿಸಿ",
        "contact-sub": "ನಿಮ್ಮಿಂದ ಕೇಳಲು ನಾವು ಬಯಸುತ್ತೇವೆ. ನಮ್ಮ ಅಧಿಕೃತ ವೇದಿಕೆಗಳ ಮೂಲಕ ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗವನ್ನು ಸಂಪರ್ಕಿಸಿ.",
        "loc-title": "📍 ನಮ್ಮ ವಿಳಾಸ",
        "loc-text": "ವಿಜಯನಗರ ವಾಟರ್ ಟ್ಯಾಂಕ್,<br>ಡಾಲ್ಫಿನ್ ಬೇಕ್ಸ್ ಎನ್ ಐಸ್ ಕ್ರೀಮ್ಸ್ ಎದುರು,<br>ಮೈಸೂರು-570017",
        "loc-btn": "🗺️ ಗೂಗಲ್ ಮ್ಯಾಪ್‌ನಲ್ಲಿ ತೆರೆಯಿರಿ",
        "insta-text": "ನಮ್ಮ ಅಧಿಕೃತ ಪುಟವನ್ನು ಫಾಲೋ ಮಾಡಿ",
        "insta-btn": "Instagram ತೆರೆಯಿರಿ",
        "threads-text": "ನಮ್ಮೊಂದಿಗೆ ಸಂಪರ್ಕದಲ್ಲಿರಿ",
        "threads-btn": "Threads ತೆರೆಯಿರಿ",
        "email-title": "📧 ಇಮೇಲ್",
        "email-text": "ಅಧಿಕೃತ ಇಮೇಲ್ ಶೀಘ್ರದಲ್ಲೇ ಲಭ್ಯವಾಗಲಿದೆ.",
        "phone-title": "📞 ಫೋನ್",
        "phone-text": "ಅಧಿಕೃತ ಸಂಪರ್ಕ ಸಂಖ್ಯೆಯನ್ನು ಶೀಘ್ರದಲ್ಲೇ ಪ್ರಕಟಿಸಲಾಗುವುದು.",
        "foot-name": "ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ",
        "foot-tag": "🤝 ಸ್ನೇಹ • 🛕 ಸಂಸ್ಕೃತಿ • ❤️ ಸೇವೆ",
        "foot-place": "📍 ಮೈಸೂರು, ಕರ್ನಾಟಕ",
        "foot-copy": "© 2026 ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ",
        "foot-dev": "ರಚನೆ: <b>Koushil R Gowda</b> ❤️",
        "foot-ver": "ವೆಬ್‌ಸೈಟ್ ಆವೃತ್ತಿ 3.0",
        "sp-cta": "💬 Instagram ನಲ್ಲಿ ಸಂದೇಶ ಕಳುಹಿಸಿ",
        "copied": "✅ ಸಂದೇಶ ನಕಲಾಗಿದೆ! Instagram ಚಾಟ್‌ನಲ್ಲಿ ಪೇಸ್ಟ್ ಮಾಡಿ ಕಳುಹಿಸಿ.",
        "sp1-msg": "ನಮಸ್ಕಾರ ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ! ನಾನು ನಿಮ್ಮ ಕಾರ್ಯಕ್ರಮ ಬೆಂಬಲಕ್ಕೆ ಸಹಕರಿಸಲು (Sponsor) ಬಯಸುತ್ತೇನೆ. ದಯವಿಟ್ಟು ವಿವರಗಳನ್ನು ತಿಳಿಸಿ.",
        "sp2-msg": "ನಮಸ್ಕಾರ ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ! ನಾನು ನಿಮ್ಮ ಅನ್ನದಾನ ಬೆಂಬಲಕ್ಕೆ ಸಹಕರಿಸಲು (Sponsor) ಬಯಸುತ್ತೇನೆ. ದಯವಿಟ್ಟು ವಿವರಗಳನ್ನು ತಿಳಿಸಿ.",
        "sp3-msg": "ನಮಸ್ಕಾರ ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ! ನಾನು ನಿಮ್ಮ ಧ್ವನಿ ಮತ್ತು ವೇದಿಕೆ ಬೆಂಬಲಕ್ಕೆ ಸಹಕರಿಸಲು (Sponsor) ಬಯಸುತ್ತೇನೆ. ದಯವಿಟ್ಟು ವಿವರಗಳನ್ನು ತಿಳಿಸಿ.",
        "sp4-msg": "ನಮಸ್ಕಾರ ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ! ನಾನು ನಿಮ್ಮ ಸಾಮಗ್ರಿ ಬೆಂಬಲಕ್ಕೆ ಸಹಕರಿಸಲು (Sponsor) ಬಯಸುತ್ತೇನೆ. ದಯವಿಟ್ಟು ವಿವರಗಳನ್ನು ತಿಳಿಸಿ.",
        "sp5-msg": "ನಮಸ್ಕಾರ ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗ! ನಾನು ಸ್ವಯಂಸೇವಕನಾಗಿ ಸೇರಲು ಬಯಸುತ್ತೇನೆ. ದಯವಿಟ್ಟು ವಿವರಗಳನ್ನು ತಿಳಿಸಿ.",
        "nav-birthday": "🎂 ಹುಟ್ಟುಹಬ್ಬ ಪೋಸ್ಟರ್",
        "bd-title": "🎂 ಹುಟ್ಟುಹಬ್ಬದ ಪೋಸ್ಟರ್ ಮೇಕರ್",
        "bd-sub": "ನಿಮ್ಮ ಫೋಟೋ ಸೇರಿಸಿ, ಐಗಿರಿ ಗೆಳೆಯರ ಬಳಗದ ಸುಂದರ ಹುಟ್ಟುಹಬ್ಬದ ಪೋಸ್ಟರ್ ಕ್ಷಣಾರ್ಧದಲ್ಲಿ ರಚಿಸಿ. ನಿಮ್ಮ ಫೋಟೋ ನಿಮ್ಮ ಫೋನ್‌ನಲ್ಲೇ ಉಳಿಯುತ್ತದೆ.",
        "bd-open": "ಹೊಸ ಟ್ಯಾಬ್‌ನಲ್ಲಿ ತೆರೆಯಿರಿ ↗",
        "mb-title": "ಐಗಿರಿ ಸದಸ್ಯ ಐಡಿ ಕಾರ್ಡ್",
        "mb-sub": "ನಿಮ್ಮ ಐಡಿ ಕಾರ್ಡ್ ನೋಡಲು ಲಾಗಿನ್ ಮಾಡಿ, ಅಥವಾ ಹೊಸದಾಗಿ ಸೈನ್ ಅಪ್ ಮಾಡಿ.",
        "mb-tab-login": "ಲಾಗಿನ್",
        "mb-tab-signup": "ಸೈನ್ ಅಪ್",
        "mb-id": "ಸದಸ್ಯ ಐಡಿ",
        "mb-pass": "ಎಜಿಬಿ ಸದಸ್ಯರ ಪಾಸ್‌ವರ್ಡ್",
        "mb-login-btn": "🔓 ಲಾಗಿನ್",
        "mb-back": "← ವೆಬ್‌ಸೈಟ್‌ಗೆ ಮರಳಿ",
        "mb-name": "ಪೂರ್ಣ ಹೆಸರು",
        "mb-phone": "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ",
        "mb-blood": "ರಕ್ತದ ಗುಂಪು",
        "mb-choose": "ಆಯ್ಕೆಮಾಡಿ…",
        "mb-year": "ಸೇರಿದ ವರ್ಷ",
        "mb-photo": "ನಿಮ್ಮ ಫೋಟೋ",
        "mb-photo-hint": "ಸ್ಪಷ್ಟ ಮುಖದ ಫೋಟೋ. ಇದು ತಾನಾಗಿ ಚಿಕ್ಕದಾಗುತ್ತದೆ.",
        "mb-pin": "PIN ರಚಿಸಿ (4–6 ಅಂಕೆ)",
        "mb-pin2": "PIN ಮತ್ತೆ ನಮೂದಿಸಿ",
        "mb-pin-hint": "ನಿಮ್ಮ ವಿವರ ಬದಲಿಸಲು ಈ PIN ಬೇಕು. ನೆನಪಿಡಿ!",
        "mb-consent": "ನನ್ನ ಐಡಿ ಕಾರ್ಡ್‌ಗಾಗಿ ನನ್ನ ವಿವರಗಳನ್ನು (ಹೆಸರು, ಫೋಟೋ, ಫೋನ್, ರಕ್ತದ ಗುಂಪು) ಎಜಿಬಿ ಉಳಿಸಿಕೊಳ್ಳಲು ನನ್ನ ಒಪ್ಪಿಗೆ ಇದೆ.",
        "mb-signup-btn": "✨ ನನ್ನ ಐಡಿ ಕಾರ್ಡ್ ರಚಿಸಿ",
        "mb-preview": "ಲೈವ್ ಪೂರ್ವವೀಕ್ಷಣೆ",
        "mb-wait": "ದಯವಿಟ್ಟು ಕಾಯಿರಿ…",
        "mb-card-title": "🪪 ನಿಮ್ಮ ಐಡಿ ಕಾರ್ಡ್",
        "mb-logout": "🚪 ಲಾಗ್ ಔಟ್",
        "mb-new": "✅ ನೋಂದಣಿ ಯಶಸ್ವಿ! ನಿಮ್ಮ ಸದಸ್ಯ ಐಡಿ {id}. ಇದನ್ನು ಬರೆದಿಟ್ಟುಕೊಳ್ಳಿ — ಲಾಗಿನ್‌ಗೆ ಬೇಕು.",
        "mb-welcome": "✅ ಸ್ವಾಗತ!",
        "mb-pending": "ಸ್ಥಿತಿ: ಎಜಿಬಿ ಪರಿಶೀಲನೆ ಬಾಕಿ.",
        "mb-active": "ಸ್ಥಿತಿ: ಪರಿಶೀಲಿತ ಸದಸ್ಯ ✔",
        "mb-v-name": "ಪೂರ್ಣ ಹೆಸರು ನಮೂದಿಸಿ (ಅಕ್ಷರಗಳು ಮಾತ್ರ).",
        "mb-v-phone": "ಸರಿಯಾದ 10 ಅಂಕೆಯ ಮೊಬೈಲ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ.",
        "mb-v-blood": "ರಕ್ತದ ಗುಂಪು ಆಯ್ಕೆಮಾಡಿ.",
        "mb-v-year": "ಸೇರಿದ ವರ್ಷ ಆಯ್ಕೆಮಾಡಿ.",
        "mb-v-photo": "ನಿಮ್ಮ ಫೋಟೋ ಸೇರಿಸಿ.",
        "mb-v-pin": "PIN 4 ರಿಂದ 6 ಅಂಕೆಗಳಾಗಿರಬೇಕು.",
        "mb-v-pin2": "ಎರಡು PIN ಗಳು ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ.",
        "mb-v-consent": "ಒಪ್ಪಿಗೆ ಬಾಕ್ಸ್ ಟಿಕ್ ಮಾಡಿ.",
        "mb-v-login": "ಸದಸ್ಯ ಐಡಿ ಮತ್ತು ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ.",
        "mb-neterr": "ಸಂಪರ್ಕ ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ಇಂಟರ್ನೆಟ್ ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.",
        "mb-dl-png": "⬇ PNG ಚಿತ್ರ",
        "mb-dl-pdf": "📄 PDF (ಮುದ್ರಣಕ್ಕೆ)",
        "mb-print": "🖨 ಪ್ರಿಂಟ್",
        "mb-dl-hint": "PDF ಮತ್ತು ಪ್ರಿಂಟ್ ಕಾರ್ಡ್‌ನ ನಿಜವಾದ ಗಾತ್ರದಲ್ಲಿವೆ (54 × 86 ಮಿಮೀ). ಪ್ರಿಂಟ್ ಮಾಡುವಾಗ 100% ಆಯ್ಕೆಮಾಡಿ.",
        "foot-member": "🪪 ಸದಸ್ಯರ ಲಾಗಿನ್",
        "vf-title": "ಸದಸ್ಯ ಪರಿಶೀಲನೆ",
        "vf-checking": "ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ…",
        "vf-ok": "✅ ಪರಿಶೀಲಿತ ಐಗಿರಿ ಸದಸ್ಯ",
        "vf-pending": "⏳ ನೋಂದಾಯಿತ — ಎಜಿಬಿ ಪರಿಶೀಲನೆ ಬಾಕಿ",
        "vf-inactive": "⚠️ ಈ ಸದಸ್ಯತ್ವ ಸಕ್ರಿಯವಾಗಿಲ್ಲ",
        "vf-notfound": "❌ ಈ ಐಡಿಯ ಸದಸ್ಯರು ಸಿಗಲಿಲ್ಲ",
        "vf-id": "ಸದಸ್ಯ ಐಡಿ",
        "vf-name": "ಹೆಸರು",
        "vf-role": "ಪಾತ್ರ",
        "vf-year": "ಸೇರಿದ ವರ್ಷ",
        "vf-note": "ಈ ಪುಟ ಹೆಸರು, ಪಾತ್ರ ಮತ್ತು ಸ್ಥಿತಿಯನ್ನು ಮಾತ್ರ ತೋರಿಸುತ್ತದೆ.",
        "vf-home": "← ವೆಬ್‌ಸೈಟ್‌ಗೆ ಮರಳಿ",
        "mb-badreply": "ಸರ್ವರ್ ನಿರೀಕ್ಷಿತವಲ್ಲದ ಉತ್ತರ ನೀಡಿದೆ. ದಯವಿಟ್ಟು ಎಜಿಬಿ ನಿರ್ವಾಹಕರಿಗೆ ತಿಳಿಸಿ.",
        "nav-join": "ಸೇರಿ / ಸ್ವಯಂಸೇವಕರಾಗಿ",
        "hero2-title": "ಒಟ್ಟಾಗಿ ಬೆಳೆಯೋಣ,<br>ಒಟ್ಟಾಗಿ ಸೇವೆ ಮಾಡೋಣ.",
        "hero2-tag": "ಸ್ನೇಹ • ಸಂಸ್ಕೃತಿ • ಸೇವೆ",
        "hero2-sub": "ಸ್ನೇಹ, ಸಂಸ್ಕೃತಿ, ಆಧ್ಯಾತ್ಮಿಕತೆ ಮತ್ತು ಸೇವೆಯ ಮೂಲಕ ಜನರನ್ನು ಒಂದುಗೂಡಿಸುವ ಯುವ ಸಮುದಾಯ.",
        "btn-explore": "ಕಾರ್ಯಕ್ರಮಗಳನ್ನು ನೋಡಿ",
        "btn-meet": "AGB ತಂಡ ಭೇಟಿ",
        "mem-title": "📸 ನೆನಪುಗಳು",
        "de-title": "✨ ಡಿಜಿಟಲ್ ಸೇವೆಗಳು",
        "de-member": "ಡಿಜಿಟಲ್ ಸದಸ್ಯ ಐಡಿ",
        "de-member-s": "ನಿಮ್ಮ AGB ಗುರುತು",
        "de-poster": "ಹುಟ್ಟುಹಬ್ಬ ಪೋಸ್ಟರ್",
        "de-poster-s": "ವಿಶೇಷ ಕ್ಷಣಗಳ ಆಚರಣೆ",
        "de-join": "ಸೇರಿ / ಸ್ವಯಂಸೇವಕರಾಗಿ",
        "de-join-s": "AGB ಯ ಭಾಗವಾಗಿ",
        "de-events": "ಕಾರ್ಯಕ್ರಮಗಳು",
        "de-events-s": "ಮಾಹಿತಿ ಪಡೆಯಿರಿ",
        "tab-home": "ಮುಖಪುಟ",
        "tab-events": "ಕಾರ್ಯಕ್ರಮ",
        "tab-gallery": "ಗ್ಯಾಲರಿ",
        "tab-support": "ಬೆಂಬಲ",
        "tab-menu": "ಮೆನು",
        "evt-venue": "📍 ಮೈಸೂರು",
        "evt-support": "ಈ ಕಾರ್ಯಕ್ರಮಕ್ಕೆ ಬೆಂಬಲ"
    },
    "en": {
        "sheet-birthday": "Birthday Poster",
        "sheet-member": "Member ID",
        "gal-title": "📸 Event Gallery",
        "gal-sub": "Photos and reels from our celebrations",
        "gal-empty": "Photos will be added soon.",
        "reel-title": "Watch our reels",
        "nav-news": "News",
        "crumb-home": "Home",
        "banner-about": "Our story, our values and our journey",
        "banner-events": "Celebrations that bring us together",
        "banner-support": "Together we serve",
        "news-title": "News & Announcements",
        "news-sub": "Latest news and announcements from AGB",
        "news-empty": "News coming soon.",
        "news-share": "Share on WhatsApp",
        "news-more": "Read more",
        "news-all": "View all news",
        "news-latest": "Latest news",
        "more-events": "All events",
        "meet-team": "Meet the full team",
        "learn-more": "Learn more",
        "stat-founded": "Founded",
        "stat-celebrations": "Celebrations",
        "stat-members": "Team members",
        "stat-upcoming": "Upcoming events",
        "foot-links": "Quick links",
        "foot-follow": "Follow us",
        "tl1": "AGB established",
        "tl2": "Celebrations & community activities",
        "tl3": "Future growth",
        "cta-title": "Be a part of AGB",
        "cta-sub": "Volunteer, support an event, or simply say hello.",
        "cd-starts": "Event starts in",
        "nav-home": "Home",
        "nav-about": "About",
        "nav-events": "Events",
        "nav-team": "AGB Team",
        "nav-gallery": "Gallery",
        "nav-sponsor": "Support",
        "nav-contact": "Contact",
        "hero-title": "AIGIRI GELEYARA BALAGA",
        "hero-city": "Mysuru",
        "hero-tagline": "Service • Friendship • Culture",
        "btn-events": "Upcoming Events",
        "connect": "Connect With Us",
        "insta-follow": "Follow us on Instagram",
        "threads-official": "Official Page",
        "slide-title": "Ganeshotsava 2025",
        "slide-sub": "Memories of Unity • Devotion • Friendship",
        "upcoming-title": "✨ Upcoming Events ✨",
        "past-title": "🕰️ Past Events",
        "t-ashada": "🪔 Ashada Pooja Mahotsava",
        "t-ganesh": "🐘 Ganeshotsava",
        "d-ashada27": "📅 30 July 2027",
        "d-ganesh27": "📅 04 September 2027",
        "cd-days": "Days",
        "cd-hours": "Hours",
        "cd-mins": "Min",
        "cd-secs": "Sec",
        "cd-live": "🙏 Event has started",
        "watch": "▶ Watch on Instagram",
        "about-title": "About AIGIRI GELEYARA BALAGA",
        "about-sub": "Serving Society Through Friendship, Culture &amp; Unity",
        "about-p1": "<strong>AIGIRI GELEYARA BALAGA (AGB), Mysuru</strong> is a youth community organization established in <strong>2025</strong> with the vision of bringing people together through friendship, culture, spirituality, and social service.",
        "about-p2": "Since its inception, AGB has been actively organizing religious celebrations, cultural events, social activities, and community service initiatives that strengthen unity and promote positive values among youth and society.",
        "about-p3": "Our flagship celebrations include <strong>Ganeshotsava</strong>, <strong>Ashada Shukravara Pooja Mahotsava</strong>, and various future initiatives dedicated to serving society, preserving traditions, and encouraging volunteerism.",
        "about-p4": "We believe that true friendship becomes meaningful when it inspires service, respect, leadership, and collective responsibility. Every member of AGB contributes towards building a stronger, united, and compassionate community.",
        "motto-title": "<strong>Our Motto:</strong>",
        "motto-1": "🟡 Service • Friendship • Culture",
        "motto-2": "🙏 Together We Grow, Together We Serve.",
        "team-title": "👥 AGB Team",
        "team-subtitle": "Meet the members of AIGIRI GELEYARA BALAGA",
        "gallery-title": "📸 Gallery",
        "gallery-subtitle": "Memories from our events",
        "g-ashada": "🪔 Ashada Pooja",
        "g-ganesh": "🐘 Ganeshotsava",
        "sponsor-title": "🤝 Support AIGIRI GELEYARA BALAGA",
        "sponsor-sub": "We welcome individuals, businesses and well-wishers who wish to support our cultural, religious and community service activities. Every contribution through volunteering, materials or event support helps us serve society better.",
        "sp1-t": "🎉 Event Support",
        "sp1-p": "Support the successful organization of our cultural and community events.",
        "sp2-t": "🍛 Annadanam Support",
        "sp2-p": "Support prasada and food distribution during our religious and community events.",
        "sp3-t": "🎵 Sound &amp; Stage Support",
        "sp3-p": "Support sound systems, lighting, stage setup and event arrangements.",
        "sp4-t": "🎁 Material Support",
        "sp4-p": "Support flowers, decorations, pooja items, drinking water, chairs and other event materials.",
        "sp5-t": "🙋 Volunteer",
        "sp5-p": "Join AIGIRI GELEYARA BALAGA as a volunteer and help us serve the community with dedication.",
        "sponsor-cta": "Interested in Supporting Our Activities?",
        "sponsor-insta": "📷 Contact on Instagram",
        "sponsor-threads": "🧵 Contact on Threads",
        "contact-title": "📍 Contact Us",
        "contact-sub": "We would love to hear from you. Connect with AIGIRI GELEYARA BALAGA through our official platforms.",
        "loc-title": "📍 Our Location",
        "loc-text": "Vijayanagar Water Tank,<br>Opposite Dolphin Bakes 'N' Ice Creams,<br>Mysuru-570017",
        "loc-btn": "🗺️ Open in Google Maps",
        "insta-text": "Follow our official page",
        "insta-btn": "Open Instagram",
        "threads-text": "Stay connected with us",
        "threads-btn": "Open Threads",
        "email-title": "📧 Email",
        "email-text": "Official Email will be available soon.",
        "phone-title": "📞 Phone",
        "phone-text": "Official Contact Number will be announced soon.",
        "foot-name": "AIGIRI GELEYARA BALAGA",
        "foot-tag": "🤝 Friendship • 🛕 Culture • ❤️ Service",
        "foot-place": "📍 Mysuru, Karnataka",
        "foot-copy": "© 2026 AIGIRI GELEYARA BALAGA",
        "foot-dev": "Developed with ❤️ by <b>Koushil R Gowda</b>",
        "foot-ver": "Website Version 3.0",
        "sp-cta": "💬 Message us on Instagram",
        "copied": "✅ Message copied! Paste it in the Instagram chat and send.",
        "sp1-msg": "Hello AIGIRI GELEYARA BALAGA! I would like to sponsor your Event Support. Please share the details.",
        "sp2-msg": "Hello AIGIRI GELEYARA BALAGA! I would like to sponsor your Annadanam Support. Please share the details.",
        "sp3-msg": "Hello AIGIRI GELEYARA BALAGA! I would like to sponsor your Sound & Stage Support. Please share the details.",
        "sp4-msg": "Hello AIGIRI GELEYARA BALAGA! I would like to sponsor your Material Support. Please share the details.",
        "sp5-msg": "Hello AIGIRI GELEYARA BALAGA! I would like to join as a Volunteer. Please share the details.",
        "nav-birthday": "🎂 Birthday Poster",
        "bd-title": "🎂 Birthday Poster Maker",
        "bd-sub": "Add your photo and create a beautiful AGB birthday poster in seconds. Your photo stays on your phone.",
        "bd-open": "Open in a new tab ↗",
        "mb-title": "AIGIRI MEMBER ID CARD",
        "mb-sub": "Log in to see your ID card, or sign up to create one.",
        "mb-tab-login": "Log in",
        "mb-tab-signup": "Sign up",
        "mb-id": "Member ID",
        "mb-pass": "AGB member password",
        "mb-login-btn": "🔓 Log in",
        "mb-back": "← Back to Website",
        "mb-name": "Full name",
        "mb-phone": "Mobile number",
        "mb-blood": "Blood group",
        "mb-choose": "Choose…",
        "mb-year": "Joining year",
        "mb-photo": "Your photo",
        "mb-photo-hint": "A clear face photo. It is made smaller automatically.",
        "mb-pin": "Create a PIN (4–6 digits)",
        "mb-pin2": "Repeat PIN",
        "mb-pin-hint": "You need this PIN to edit your details. Remember it!",
        "mb-consent": "I agree that AGB may store my details (name, photo, phone, blood group) to make my ID card.",
        "mb-signup-btn": "✨ Create my ID card",
        "mb-preview": "Live preview",
        "mb-wait": "Please wait…",
        "mb-card-title": "🪪 Your ID Card",
        "mb-logout": "🚪 Log out",
        "mb-new": "✅ Registered! Your Member ID is {id}. Please write it down — you need it to log in.",
        "mb-welcome": "✅ Welcome!",
        "mb-pending": "Status: Waiting for AGB to verify.",
        "mb-active": "Status: Verified member ✔",
        "mb-v-name": "Enter your full name (letters only).",
        "mb-v-phone": "Enter a valid 10-digit mobile number.",
        "mb-v-blood": "Choose your blood group.",
        "mb-v-year": "Choose your joining year.",
        "mb-v-photo": "Please add your photo.",
        "mb-v-pin": "PIN must be 4 to 6 digits.",
        "mb-v-pin2": "The two PINs do not match.",
        "mb-v-consent": "Please tick the consent box.",
        "mb-v-login": "Enter your Member ID and password.",
        "mb-neterr": "Could not connect. Check your internet and try again.",
        "mb-dl-png": "⬇ PNG picture",
        "mb-dl-pdf": "📄 PDF (for printing)",
        "mb-print": "🖨 Print",
        "mb-dl-hint": "The PDF and Print are exactly card size (54 × 86 mm). When printing, choose 100% (actual size).",
        "foot-member": "🪪 Member Login",
        "vf-title": "Member Verification",
        "vf-checking": "Checking…",
        "vf-ok": "✅ Verified AIGIRI member",
        "vf-pending": "⏳ Registered — waiting for AGB to verify",
        "vf-inactive": "⚠️ This membership is not active",
        "vf-notfound": "❌ No member found with this ID",
        "vf-id": "Member ID",
        "vf-name": "Name",
        "vf-role": "Role",
        "vf-year": "Joined",
        "vf-note": "This page only shows name, role and status.",
        "vf-home": "← Back to Website",
        "mb-badreply": "The server replied in an unexpected way. Please tell the AGB admin.",
        "nav-join": "Join / Volunteer",
        "hero2-title": "Together We Grow,<br>Together We Serve.",
        "hero2-tag": "Friendship • Culture • Service",
        "hero2-sub": "A youth community bringing people together through friendship, culture, spirituality and service.",
        "btn-explore": "Explore Events",
        "btn-meet": "Meet AGB",
        "mem-title": "📸 Explore Memories",
        "de-title": "✨ Digital Ecosystem",
        "de-member": "Digital Member ID",
        "de-member-s": "Your AGB identity",
        "de-poster": "Birthday Poster Maker",
        "de-poster-s": "Celebrate special moments",
        "de-join": "Join / Volunteer",
        "de-join-s": "Be part of AGB",
        "de-events": "Events",
        "de-events-s": "Stay updated",
        "tab-home": "Home",
        "tab-events": "Events",
        "tab-gallery": "Gallery",
        "tab-support": "Support",
        "tab-menu": "Menu",
        "evt-venue": "📍 Mysuru",
        "evt-support": "Support this event"
    }
};

const langBtn = document.getElementById("langBtn");
let currentLanguage = localStorage.getItem("language") === "en" ? "en" : "kn";

function changeLanguage(language) {
    document.querySelectorAll("[data-i18n]").forEach(el => {
        const text = translations[language][el.dataset.i18n];
        if (text !== undefined) el.innerHTML = text;
    });

    // Placeholders inside input boxes use data-i18n-ph
    document.querySelectorAll("[data-i18n-ph]").forEach(el => {
        const text = translations[language][el.dataset.i18nPh];
        if (text !== undefined) el.placeholder = text;
    });

    document.documentElement.lang = language;
    langBtn.textContent = language === "kn" ? "🌐 English" : "🌐 ಕನ್ನಡ";
    localStorage.setItem("language", language);
    currentLanguage = language;
    updateEventBadges();
    renderNews();
}

changeLanguage(currentLanguage);

langBtn.addEventListener("click", () => {
    changeLanguage(currentLanguage === "kn" ? "en" : "kn");
});


// ===== 3. Mobile Menu =====
const menuToggle = document.getElementById("menuToggle");
const navMenu = document.querySelector(".nav-links");

if (menuToggle && navMenu) {
    menuToggle.addEventListener("click", () => {
        navMenu.classList.toggle("active");
        menuToggle.textContent = navMenu.classList.contains("active") ? "✖" : "☰";
    });

    navMenu.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", () => {
            navMenu.classList.remove("active");
            menuToggle.textContent = "☰";
        });
    });
}


// Bottom tab bar on phones: "Menu" opens the same menu as the ☰ button
const tabMenu = document.getElementById("tabMenu");
const menuSheet = document.getElementById("menuSheet");
const sheetBackdrop = document.getElementById("sheetBackdrop");

function setSheet(open) {
    menuSheet.classList.toggle("open", open);
    sheetBackdrop.classList.toggle("open", open);
    menuSheet.setAttribute("aria-hidden", open ? "false" : "true");
}

if (tabMenu && menuSheet) {
    tabMenu.addEventListener("click", () => setSheet(!menuSheet.classList.contains("open")));
    sheetBackdrop.addEventListener("click", () => setSheet(false));
    menuSheet.querySelectorAll("a").forEach(link => link.addEventListener("click", () => setSheet(false)));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") setSheet(false); });
}


// ===== 4. Scroll effects (shrinking navbar + back-to-top button) =====
const navbar = document.querySelector(".navbar");
const topBtn = document.getElementById("topBtn");

window.addEventListener("scroll", () => {
    navbar.classList.toggle("scrolled", window.scrollY > 20);
    topBtn.style.display = window.scrollY > 300 ? "block" : "none";
});

topBtn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
});


// ===== 5. Random team order on every visit =====
const teamGrid = document.querySelector(".team-grid");

if (teamGrid) {
    const cards = Array.from(teamGrid.children);

    for (let i = cards.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [cards[i], cards[j]] = [cards[j], cards[i]];
    }

    cards.forEach(card => teamGrid.appendChild(card));
}


// ===== 6. Loader =====
window.addEventListener("load", () => {
    const loader = document.getElementById("loader");
    if (!loader) return;   // pages without a loader (like birthday.html)
    setTimeout(() => {
        loader.style.opacity = "0";
        setTimeout(() => { loader.style.display = "none"; }, 600);
    }, 1800);
});


// ===== 7. Photo slider =====
// Add or remove photos here (files are in images/gallery-slider/)
const galleryImages = [
    "images/gallery-slider/photo1.jpg",
    "images/gallery-slider/photo2.jpg",
    "images/gallery-slider/photo3.jpg",
    "images/gallery-slider/photo4.jpg",
    "images/gallery-slider/photo5.jpg",
    "images/gallery-slider/photo6.jpg",
    "images/gallery-slider/photo7.jpg",
    "images/gallery-slider/photo8.jpg"
];

let galleryIndex = 0;
const sliderImage = document.getElementById("sliderImage");
const dotsContainer = document.getElementById("sliderDots");

function updateDots() {
    document.querySelectorAll("#sliderDots span").forEach((dot, i) => {
        dot.classList.toggle("active", i === galleryIndex);
    });
}

function showSlide(index) {
    galleryIndex = (index + galleryImages.length) % galleryImages.length;
    sliderImage.src = galleryImages[galleryIndex];
    updateDots();
}

if (sliderImage) {

    // Auto-play every 4 seconds with a short fade
    setInterval(() => {
        sliderImage.style.opacity = 0;
        setTimeout(() => {
            showSlide(galleryIndex + 1);
            sliderImage.style.opacity = 1;
        }, 300);
    }, 4000);

    document.getElementById("prevSlide").onclick = () => showSlide(galleryIndex - 1);
    document.getElementById("nextSlide").onclick = () => showSlide(galleryIndex + 1);

    if (dotsContainer) {
        galleryImages.forEach((img, index) => {
            const dot = document.createElement("span");
            if (index === 0) dot.classList.add("active");
            dot.onclick = () => showSlide(index);
            dotsContainer.appendChild(dot);
        });
    }

    // Full screen viewer
    const imageViewer = document.getElementById("imageViewer");
    const fullImage = document.getElementById("fullImage");

    // Photos ignore the mouse (see style.css), so the click is caught by the slider box
    document.querySelector(".slider").onclick = (e) => {
        if (e.target.closest("button")) return;
        fullImage.src = sliderImage.src;
        imageViewer.style.display = "flex";
    };

    document.getElementById("closeViewer").onclick = () => {
        imageViewer.style.display = "none";
    };

    imageViewer.onclick = (e) => {
        if (e.target === imageViewer) imageViewer.style.display = "none";
    };
}


// ===== 8. Upcoming events countdown (royal glass timer) =====
// Shows a number; when it changes the number slides in again.
function setNumber(el, value) {
    const text = String(value);
    if (el.textContent === text) return;
    el.textContent = text;
    el.classList.remove("tick");
    void el.offsetWidth;                                 // restart the animation
    el.classList.add("tick");
}

// To change a date, edit data-date="YYYY-MM-DDTHH:MM:SS" in the page
document.querySelectorAll(".countdown-card").forEach(card => {
    const target = new Date(card.dataset.date).getTime();
    const box = card.querySelector(".countdown");
    const days = card.querySelector(".cd-days");
    const hours = card.querySelector(".cd-hours");
    const mins = card.querySelector(".cd-mins");
    const secs = card.querySelector(".cd-secs");
    const fill = card.querySelector("cd-fill");
    let timer;

    function tick() {
        const diff = target - Date.now();

        if (diff <= 0) {
            box.innerHTML = '<p class="cd-live" data-i18n="cd-live"></p>';
            changeLanguage(currentLanguage);
            clearInterval(timer);
            return;
        }

        setNumber(days, Math.floor(diff / 86400000));
        setNumber(hours, String(Math.floor(diff / 3600000) % 24).padStart(2, "0"));
        setNumber(mins, String(Math.floor(diff / 60000) % 60).padStart(2, "0"));
        setNumber(secs, String(Math.floor(diff / 1000) % 60).padStart(2, "0"));

        // the gold bar fills up during the last 365 days before the event
        if (fill) fill.style.width = (100 * (1 - Math.min(1, diff / (365 * 86400000)))).toFixed(1) + "%";
    }

    tick();
    timer = setInterval(tick, 1000);
});


// ===== 9. Support boxes -> Instagram message =====
// Tapping a box copies a ready message and opens our Instagram chat.
// (Instagram does not allow pre-filled text in links, so the user pastes it.)
const toast = document.getElementById("toast");
let toastTimer;

function showToast() {
    toast.textContent = translations[currentLanguage].copied;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 6000);
}

function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text);
    }
    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
    return Promise.resolve();
}

document.querySelectorAll("[data-msg]").forEach(card => {
    card.addEventListener("click", () => {
        const message = translations[currentLanguage][card.dataset.msg];
        copyText(message).then(showToast).catch(showToast);
    });
});


// ===== 10. Image protection =====
// Stops casual saving of photos (right-click, long-press, dragging).
// It cannot stop screenshots. To allow saving on one image, put it
// inside any element with class="allow-save".
function isProtectedImage(target) {
    return target.tagName === "IMG" && !target.closest(".allow-save");
}

document.addEventListener("contextmenu", (e) => {
    if (isProtectedImage(e.target)) e.preventDefault();
});

document.addEventListener("dragstart", (e) => {
    if (isProtectedImage(e.target)) e.preventDefault();
});


// ===== 11. Birthday poster page: frame grows to fit the poster maker =====
// The poster maker lives on the same website address, so we are allowed
// to read its height and make our frame exactly that tall (no inner scrolling).
const posterFrame = document.getElementById("posterFrame");

if (posterFrame) {
    posterFrame.addEventListener("load", () => {
        try {
            const doc = posterFrame.contentDocument;

            const fitHeight = () => {
                posterFrame.style.height = "0px";   // shrink first to measure real content height
                posterFrame.style.height = doc.documentElement.scrollHeight + "px";
            };

            fitHeight();
            new ResizeObserver(fitHeight).observe(doc.body);
        } catch (error) {
            console.log("Poster frame could not be resized:", error);
        }
    });
}


// Date badge on each upcoming event photo (day number + month name in the chosen language)
function updateEventBadges() {
    document.querySelectorAll(".countdown-card").forEach(card => {
        const day = card.querySelector(".evt-day");
        const month = card.querySelector(".evt-mon");
        if (!day || !month) return;
        const date = new Date(card.dataset.date);
        day.textContent = date.getDate();
        month.textContent = date.toLocaleString(currentLanguage === "kn" ? "kn-IN" : "en-IN", { month: "short" });
    });
}
updateEventBadges();


// ===== 12. Icons: every emoji on the page becomes one of our own drawn icons =====
// The pictures live in the hidden icon sheet at the top of each page (<symbol id="i-...">).
const ICON_MAP = {"🪔": "lamp", "🐘": "modak", "📅": "calendar", "🙏": "namaste", "🟡": "diamond", "👥": "people", "📸": "camera", "🤝": "united", "🎉": "sparkle", "🍛": "bowl", "🎵": "music", "🎁": "gift", "🙋": "hand", "📍": "pin", "🗺": "map", "📧": "mail", "📞": "phone", "📷": "camera", "🧵": "at", "🕰": "clock", "✨": "sparkle", "🪪": "idcard", "🎂": "cake", "🔓": "unlock", "🔒": "lock", "🚪": "door", "⬇": "download", "📄": "document", "🖨": "printer", "✅": "check", "⏳": "hourglass", "❌": "cross", "⚠": "warning", "🛕": "temple", "❤": "heart", "🌐": "globe", "🌙": "moon", "☀": "sun", "⬆": "arrowup", "👤": "user", "🔧": "wrench", "▶": "play", "🏠": "home", "🖼": "image", "💬": "chat", "✔": "tick"};
const ICON_PATTERN = "(" + Object.keys(ICON_MAP).join("|") + ")\\uFE0F?";

function makeIcon(name) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("class", "ic ic-" + name);
    svg.setAttribute("aria-hidden", "true");
    const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", "#i-" + name);
    svg.appendChild(use);
    return svg;
}

function iconize(root) {
    const finder = new RegExp(ICON_PATTERN);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
            const tag = node.parentNode && node.parentNode.nodeName;
            if (!tag || /^(SCRIPT|STYLE|TEXTAREA|NOSCRIPT|TITLE|OPTION)$/.test(tag)) return NodeFilter.FILTER_REJECT;
            return finder.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        }
    });

    const found = [];
    while (walker.nextNode()) found.push(walker.currentNode);

    found.forEach(node => {
        const text = node.nodeValue;
        const fragment = document.createDocumentFragment();
        let last = 0;
        text.replace(new RegExp(ICON_PATTERN, "g"), (match, emoji, position) => {
            fragment.appendChild(document.createTextNode(text.slice(last, position)));
            fragment.appendChild(makeIcon(ICON_MAP[emoji]));
            last = position + match.length;
            return match;
        });
        fragment.appendChild(document.createTextNode(text.slice(last)));
        node.parentNode.replaceChild(fragment, node);
    });
}

// run now, and again whenever the page changes its text (language, messages, countdown...)
let iconTimer;
const iconWatcher = new MutationObserver(() => {
    clearTimeout(iconTimer);
    iconTimer = setTimeout(() => {
        iconWatcher.disconnect();
        iconize(document.body);
        iconWatcher.observe(document.body, { childList: true, subtree: true, characterData: true });
    }, 30);
});
iconize(document.body);
iconWatcher.observe(document.body, { childList: true, subtree: true, characterData: true });

// ===== 13. Event gallery: slideshow + photo grid + reel cards =====
// The photo lists come straight from your GitHub folders, so any file names work.
// If GitHub cannot be asked, the page guesses photo1.jpg, photo2.jpg ... instead.
const REPO = "koushil24/aigiri-geleyara-balaga";
const ALBUMS = {
    ashada2025: { slug: "ashada-2025", folders: ["images/ashada-2025/", "images/events/ashada-2025/"], reel: "https://www.instagram.com/reel/DPC3tYskmFy/?igsh=MTkzZGs1MW9qZ2EzaA==" },
    ganesh2025: { slug: "ganeshotsava-2025", folders: ["images/ganeshotsava-2025/", "images/events/ganeshotsava-2025/", "images/gallery-slider/"], reel: "https://www.instagram.com/reel/DN8gSypiRLA/?igsh=dmU1NnNwOHFoaWNv" },
    ashada2026: { slug: "ashada-2026", folders: ["images/ashada-2026/", "images/events/ashada-2026/"], reel: "https://www.instagram.com/reel/DcJg-cJxuG5/?stkn=bm42NjNkZDg2bndz" },
    ganesh2026: { slug: "ganeshotsava-2026", folders: ["images/ganeshotsava-2026/", "images/events/ganeshotsava-2026/"], reel: "https://www.instagram.com/reel/DddP9tUpsAl/?stkn=MXJiZWRmaHQyaDB5ag==" }
};

const albumCache = {};                                   // album name -> list of photo addresses
const albumState = { name: "", photos: [], index: 0, timer: null, pausedUntil: 0 };

const stageBox = document.getElementById("albumStage");
const stageImg = document.getElementById("stageImg");
const stageBg = document.getElementById("stageBg");
const stageCount = document.getElementById("stageCount");
const thumbsBox = document.getElementById("thumbs");
const albumEmpty = document.getElementById("albumEmpty");
const albumTabs = document.querySelectorAll(".album-tab");

// ---- the list of all image files in the repository (one question to GitHub, remembered for 10 minutes) ----
let treePromise;

async function loadTree() {
    try {
        const saved = JSON.parse(localStorage.getItem("agbTree") || "null");
        if (saved && Date.now() - saved.time < 10 * 60 * 1000) return saved.paths;
    } catch (error) { /* ignore */ }

    try {
        const response = await fetch("https://api.github.com/repos/" + REPO + "/git/trees/main?recursive=1");
        if (!response.ok) throw new Error("GitHub answered " + response.status);
        const data = await response.json();
        const paths = data.tree
            .filter(item => item.type === "blob" && /^images\/.*\.(jpe?g|png|webp|gif)$/i.test(item.path))
            .map(item => item.path);
        try { localStorage.setItem("agbTree", JSON.stringify({ time: Date.now(), paths: paths })); } catch (error) { /* ignore */ }
        return paths;
    } catch (error) {
        return null;                                     // null = could not ask GitHub
    }
}

function getTree() {
    if (!treePromise) treePromise = loadTree();
    return treePromise;
}

// ---- backup way: guess photo1.jpg, photo2.jpg ... ----
function photoExists(url) {
    return fetch(url, { method: "HEAD" }).then(r => r.ok).catch(() => false);
}

async function findPhotos(folder) {
    const found = [];
    for (let start = 1; start <= 60; start += 10) {
        const group = [];
        for (let n = start; n < start + 10; n++) group.push(folder + "photo" + n + ".jpg");
        const answers = await Promise.all(group.map(photoExists));
        const hits = group.filter((url, i) => answers[i]);
        found.push(...hits);
        if (hits.length === 0) break;
    }
    return found;
}

// the photos of one album: the first folder that has photos wins
async function photosFor(name) {
    if (albumCache[name]) return albumCache[name];
    const paths = await getTree();
    let list = [];

    for (const folder of ALBUMS[name].folders) {
        if (paths) {
            list = paths
                .filter(p => p.startsWith(folder) && p.indexOf("/", folder.length) === -1)
                .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
                .map(p => encodeURI(p));
        } else {
            list = await findPhotos(folder);
        }
        if (list.length) break;
    }
    albumCache[name] = list;
    return list;
}

// ---- slideshow ----
function showPhoto(index) {
    const photos = albumState.photos;
    if (!photos.length) return;
    albumState.index = (index + photos.length) % photos.length;
    const url = photos[albumState.index];

    stageImg.classList.add("swap");
    const loader = new Image();
    const finish = () => {
        stageImg.src = url;
        stageBg.style.backgroundImage = 'url("' + url + '")';
        stageImg.classList.remove("swap");
    };
    loader.onload = finish;
    loader.onerror = finish;
    loader.src = url;

    stageCount.textContent = (albumState.index + 1) + " / " + photos.length;
    thumbsBox.querySelectorAll("button").forEach((b, i) => b.classList.toggle("on", i === albumState.index));
}

function startAutoplay() {
    clearInterval(albumState.timer);
    albumState.timer = setInterval(() => {
        if (document.hidden || Date.now() < albumState.pausedUntil || !document.getElementById("lightbox").hidden) return;
        showPhoto(albumState.index + 1);
    }, 4500);
}

function pauseAutoplay() {
    albumState.pausedUntil = Date.now() + 9000;          // after a tap or swipe, wait 9 seconds
}

async function openAlbum(name) {
    albumState.name = name;
    albumState.pausedUntil = 0;                          // a new album always starts playing
    clearInterval(albumState.timer);
    albumTabs.forEach(t => t.classList.toggle("on", t.dataset.album === name));

    const list = await photosFor(name);
    if (albumState.name !== name) return;                // another tab was chosen meanwhile

    albumState.photos = list;
    thumbsBox.innerHTML = "";

    if (!list.length) {
        stageBox.hidden = true;
        albumEmpty.hidden = false;
        return;
    }
    stageBox.hidden = false;
    albumEmpty.hidden = true;

    list.forEach((url, i) => {
        const button = document.createElement("button");
        button.type = "button";
        button.setAttribute("aria-label", "Photo " + (i + 1));
        const img = document.createElement("img");
        img.src = url;
        img.alt = "";
        img.loading = "lazy";
        button.appendChild(img);
        button.addEventListener("click", () => { pauseAutoplay(); showPhoto(i); });
        thumbsBox.appendChild(button);
    });

    showPhoto(0);
    startAutoplay();
}

// ---- reel cards: a picture + tap to open the reel on Instagram ----
// Picture = images/reels/<album>.jpg if you upload one, otherwise the first photo of the album.
async function setupReelCards() {
    const paths = await getTree();
    for (const card of document.querySelectorAll(".reel-card")) {
        const name = card.dataset.album;
        card.href = ALBUMS[name].reel;

        const custom = "images/reels/" + ALBUMS[name].slug + ".jpg";
        const hasCustom = paths ? paths.includes(custom) : await photoExists(custom);
        let url = hasCustom ? custom : "";
        if (!url) {
            const list = await photosFor(name);
            url = list[0] || "";
        }
        if (url) card.querySelector(".reel-thumb").style.backgroundImage = 'url("' + url + '")';
    }
}

if (stageBox) {
    albumTabs.forEach(tab => tab.addEventListener("click", () => openAlbum(tab.dataset.album)));

    document.getElementById("stagePrev").addEventListener("click", (e) => { e.stopPropagation(); pauseAutoplay(); showPhoto(albumState.index - 1); });
    document.getElementById("stageNext").addEventListener("click", (e) => { e.stopPropagation(); pauseAutoplay(); showPhoto(albumState.index + 1); });

    // swipe on the big photo
    let touchStartX = 0;
    stageBox.addEventListener("touchstart", (e) => { touchStartX = e.touches[0].clientX; pauseAutoplay(); }, { passive: true });
    stageBox.addEventListener("touchend", (e) => {
        const move = e.changedTouches[0].clientX - touchStartX;
        if (Math.abs(move) > 45) showPhoto(albumState.index + (move < 0 ? 1 : -1));
    }, { passive: true });

    // full-screen viewer
    const lightbox = document.getElementById("lightbox");
    const lightboxImg = document.getElementById("lbImg");
    const lightboxCount = document.getElementById("lbCount");

    function lightboxShow(index) {
        const photos = albumState.photos;
        albumState.index = (index + photos.length) % photos.length;
        lightboxImg.src = photos[albumState.index];
        lightboxCount.textContent = (albumState.index + 1) + " / " + photos.length;
    }
    function lightboxClose() {
        lightbox.hidden = true;
        showPhoto(albumState.index);
    }

    stageBox.addEventListener("click", () => { lightbox.hidden = false; lightboxShow(albumState.index); });
    document.getElementById("lbClose").addEventListener("click", lightboxClose);
    document.getElementById("lbPrev").addEventListener("click", () => lightboxShow(albumState.index - 1));
    document.getElementById("lbNext").addEventListener("click", () => lightboxShow(albumState.index + 1));
    lightbox.addEventListener("click", (e) => { if (e.target === lightbox) lightboxClose(); });
    document.addEventListener("keydown", (e) => {
        if (lightbox.hidden) return;
        if (e.key === "Escape") lightboxClose();
        if (e.key === "ArrowRight") lightboxShow(albumState.index + 1);
        if (e.key === "ArrowLeft") lightboxShow(albumState.index - 1);
    });
    let boxTouchX = 0;
    lightbox.addEventListener("touchstart", (e) => { boxTouchX = e.touches[0].clientX; }, { passive: true });
    lightbox.addEventListener("touchend", (e) => {
        const move = e.changedTouches[0].clientX - boxTouchX;
        if (Math.abs(move) > 45) lightboxShow(albumState.index + (move < 0 ? 1 : -1));
    }, { passive: true });

    // start loading only when the gallery comes into view
    const startGallery = () => { openAlbum("ganesh2026"); setupReelCards(); };
    const gallerySection = document.getElementById("gallery");
    if ("IntersectionObserver" in window) {
        const watcher = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) { watcher.disconnect(); startGallery(); }
        }, { rootMargin: "300px" });
        watcher.observe(gallerySection);
    } else {
        startGallery();
    }
}

// ===== 14. Cinematic page change: temple doors =====
(function () {
    const root = document.documentElement;
    const doors = document.getElementById("doors");
    if (!doors) return;

    // arriving from another page: the doors are shut, now they open
    if (root.classList.contains("doors-closed")) {
        try { sessionStorage.removeItem("agbDoor"); } catch (e) { /* ignore */ }
        const open = () => root.classList.remove("doors-closed");
        requestAnimationFrame(() => setTimeout(open, 350));
        setTimeout(open, 2500);                              // safety: never stay shut
    }
    try { sessionStorage.setItem("agbSeen", "1"); } catch (e) { /* ignore */ }

    // leaving: close the doors, then go to the other page
    document.addEventListener("click", (e) => {
        const link = e.target.closest("a[href]");
        if (!link || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        if (link.target === "_blank" || link.hasAttribute("download")) return;

        const url = new URL(link.href, location.href);
        if (url.origin !== location.origin || !/(\.html|\/)$/.test(url.pathname)) return;
        if (url.pathname === location.pathname) return;       // same page (# links)
        if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;

        e.preventDefault();
        try { sessionStorage.setItem("agbDoor", "1"); } catch (err) { /* ignore */ }
        doors.classList.add("closing");
        setTimeout(() => { location.href = link.href; }, 700);
    });

    // coming back with the browser Back button
    window.addEventListener("pageshow", (e) => {
        if (e.persisted) {
            doors.classList.remove("closing");
            root.classList.remove("doors-closed");
        }
    });
})();


// ===== 15. News: cards built from js/news-data.js =====
function renderNews() {
    if (typeof NEWS === "undefined") return;
    const lang = currentLanguage;
    const locale = lang === "kn" ? "kn-IN" : "en-IN";
    const sorted = NEWS.slice().sort((a, b) => b.date.localeCompare(a.date));

    function makeCard(item) {
        const title = item.title[lang] || item.title.en;
        const text = item.text[lang] || item.text.en;
        const date = new Date(item.date + "T00:00:00");

        const article = document.createElement("article");
        article.className = "news-card";

        const badge = document.createElement("div");
        badge.className = "news-date";
        const day = document.createElement("b");
        day.textContent = date.getDate();
        const month = document.createElement("span");
        month.textContent = date.toLocaleString(locale, { month: "short" }) + " " + date.getFullYear();
        badge.append(day, month);
        article.appendChild(badge);

        if (item.image) {
            const img = document.createElement("img");
            img.className = "news-img";
            img.src = item.image;
            img.alt = "";
            img.loading = "lazy";
            article.appendChild(img);
        }

        const body = document.createElement("div");
        body.className = "news-body";
        const heading = document.createElement("h3");
        heading.textContent = title;
        const paragraph = document.createElement("p");
        paragraph.textContent = text;
        const actions = document.createElement("div");
        actions.className = "news-actions";

        if (item.link) {
            const more = document.createElement("a");
            more.className = "btn btn-sm";
            more.href = item.link;
            more.textContent = translations[lang]["news-more"];
            if (/^https?:/.test(item.link)) { more.target = "_blank"; more.rel = "noopener"; }
            actions.appendChild(more);
        }

        const share = document.createElement("a");
        share.className = "btn btn-sm btn-outline-dark";
        share.target = "_blank";
        share.rel = "noopener";
        share.href = "https://wa.me/?text=" + encodeURIComponent(title + "\n" + text + "\n" + new URL("news.html", location.href).href);
        share.textContent = translations[lang]["news-share"];
        actions.appendChild(share);

        body.append(heading, paragraph, actions);
        article.appendChild(body);
        return article;
    }

    const fill = (box, items) => {
        box.innerHTML = "";
        items.forEach(item => box.appendChild(makeCard(item)));
    };

    const fullList = document.getElementById("newsList");
    const homeList = document.getElementById("homeNews");
    const empty = document.getElementById("newsEmpty");
    if (fullList) { fill(fullList, sorted); if (empty) empty.hidden = sorted.length > 0; }
    if (homeList) fill(homeList, sorted.slice(0, 3));
}
renderNews();


// ===== 16. Scroll reveal + count-up numbers =====
(function () {
    if (!("IntersectionObserver" in window) || matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const nodes = document.querySelectorAll(".card, .team-card, .evt, .eco a, .reel-card, .news-card, .stat, .tl-step, .about-card");
    nodes.forEach(el => el.classList.add("reveal"));

    const watcher = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            entry.target.classList.add("in");
            watcher.unobserve(entry.target);
        });
    }, { threshold: 0.12 });
    nodes.forEach(el => watcher.observe(el));

    const counterWatcher = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            counterWatcher.unobserve(entry.target);
            const el = entry.target;
            const end = Number(el.dataset.count);
            const suffix = el.dataset.suffix || "";
            const start = performance.now();
            const step = (now) => {
                const progress = Math.min(1, (now - start) / 1300);
                el.textContent = Math.round(end * (1 - Math.pow(1 - progress, 3))) + (progress === 1 ? suffix : "");
                if (progress < 1) requestAnimationFrame(step);
            };
            requestAnimationFrame(step);
        });
    }, { threshold: 0.5 });
    document.querySelectorAll("[data-count]").forEach(el => counterWatcher.observe(el));
})();
